package all

import (
	_ "github.com/srl-labs/containerlab/runtime/containerd"
	_ "github.com/srl-labs/containerlab/runtime/docker"
	_ "github.com/srl-labs/containerlab/runtime/ignite"
)
