package types

const (
	// env var containing the expected number of interfaces injected into every container
	CLAB_ENV_INTFS = "CLAB_INTFS"
)
